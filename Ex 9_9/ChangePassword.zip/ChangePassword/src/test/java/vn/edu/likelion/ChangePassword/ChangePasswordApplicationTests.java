package vn.edu.likelion.ChangePassword;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChangePasswordApplicationTests {

	@Test
	void contextLoads() {
	}

}
