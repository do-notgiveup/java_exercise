package vn.edu.likelion.Day21_JavaCVPDF;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day21JavaCvpdfApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day21JavaCvpdfApplication.class, args);
	}

}
