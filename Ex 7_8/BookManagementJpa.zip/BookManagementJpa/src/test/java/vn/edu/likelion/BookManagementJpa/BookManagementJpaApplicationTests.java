package vn.edu.likelion.BookManagementJpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookManagementJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
