package vn.edu.likelion.BookManagementJpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookManagementJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookManagementJpaApplication.class, args);
	}

}
